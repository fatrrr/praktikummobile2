package com.example.modul4.ui.ram

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.modul4.R
import com.example.modul4.model.CPUData
import com.example.modul4.model.RAMData

class RAMViewModel : ViewModel() {

    private val _name = MutableLiveData<String>()
    val name: LiveData<String> = _name

    private val _price = MutableLiveData<String>()
    val price: LiveData<String> = _price

    private val _desc = MutableLiveData<String>()
    val desc: LiveData<String> = _desc

    private val _image = MutableLiveData<Int>()
    val image: LiveData<Int> = _image

    fun loadData(): List<RAMData>{
        return listOf(
            RAMData(R.string.ram1, R.string.ramprice1, R.string.ramdesc1, R.drawable.ram1),
            RAMData(R.string.ram2, R.string.ramprice2, R.string.ramdesc2, R.drawable.ram2),
            RAMData(R.string.ram3, R.string.ramprice3, R.string.ramdesc3, R.drawable.ram3),
            RAMData(R.string.ram4, R.string.ramprice4, R.string.ramdesc4, R.drawable.ram4),
            RAMData(R.string.ram5, R.string.ramprice5, R.string.ramdesc5, R.drawable.ram5),
        )
    }
    fun setData(data: RAMData, context: Context){
        _name.value = context.getString(data.nameResourceId)
        _price.value = context.getString(data.priceResourceId)
        _desc.value = context.getString(data.descResourceId)
        _image.value = data.imgResourceId
    }
}