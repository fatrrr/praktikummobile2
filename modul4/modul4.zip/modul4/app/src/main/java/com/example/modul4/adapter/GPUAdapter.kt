package com.example.modul4.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.modul4.R
import com.example.modul4.model.GPUData
import com.example.modul4.ui.gpu.GPUDetailActivity
import com.example.modul4.ui.gpu.GPUViewModel

class GPUAdapter (
    private val context: Context,
    private val dataset: List<GPUData>
): RecyclerView.Adapter<GPUAdapter.GPUViewHolder>() {
    private val viewModel = GPUViewModel()

    class GPUViewHolder(val view: View) : RecyclerView.ViewHolder(view){
        val imgView: ImageView = view.findViewById(R.id.imageView)
        val nameText: TextView = view.findViewById(R.id.textName)
        val priceText: TextView = view.findViewById(R.id.textPrice)
        val descText: TextView = view.findViewById(R.id.textDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GPUViewHolder {
        val adapterLayout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.list_item, parent, false)
        return GPUViewHolder(adapterLayout)
    }


    override fun onBindViewHolder(holder: GPUViewHolder, position: Int) {
        val item = dataset[position]
        holder.nameText.text = context.resources.getString(item.nameResourceId)
        holder.priceText.text = context.resources.getString(item.priceResourceId)
        holder.descText.text = context.resources.getString(item.descResourceId)
        holder.imgView.setImageResource(item.imgResourceId)

        holder.view.setOnClickListener {
            viewModel.setData(item, context)
            val intent = Intent(context, GPUDetailActivity::class.java).apply {
                putExtra("image", viewModel.image.value)
                putExtra("name", viewModel.name.value)
                putExtra("price", viewModel.price.value)
                putExtra("desc", viewModel.desc.value)
            }
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = dataset.size
}