package com.example.modul4.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes


data class CPUData(
    @StringRes val nameResourceId : Int,
    @StringRes val priceResourceId : Int,
    @StringRes val descResourceId : Int,
    @DrawableRes val imgResourceId : Int
)