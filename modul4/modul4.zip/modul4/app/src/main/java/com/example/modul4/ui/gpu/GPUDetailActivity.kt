package com.example.modul4.ui.gpu

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.modul4.databinding.ActivityGpuDetailBinding

class GPUDetailActivity : AppCompatActivity(){
    private var _binding: ActivityGpuDetailBinding? = null
    private val binding get() = _binding!!

    companion object{
        const val EXTRA_IMAGE = "image"
        const val EXTRA_NAME = "name"
        const val EXTRA_PRICE = "price"
        const val EXTRA_DESCRIPTION = "description"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityGpuDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val img = binding.imgGpuDetail
        img.setImageResource(intent.getIntExtra(EXTRA_IMAGE, 0))

        val name = binding.nameGpuDetail
        name.text = intent.getStringExtra(EXTRA_NAME)

        val price = binding.priceGpuDetail
        price.text = intent.getStringExtra(EXTRA_PRICE)

        val desc = binding.descGpuDetail
        desc.text = intent.getStringExtra(EXTRA_DESCRIPTION)
    }
}