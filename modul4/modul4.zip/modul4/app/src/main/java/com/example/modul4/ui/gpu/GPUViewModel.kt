package com.example.modul4.ui.gpu

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.modul4.R
import com.example.modul4.model.CPUData
import com.example.modul4.model.GPUData

class GPUViewModel : ViewModel() {

    private val _name = MutableLiveData<String>()
    val name: LiveData<String> = _name

    private val _price = MutableLiveData<String>()
    val price: LiveData<String> = _price

    private val _desc = MutableLiveData<String>()
    val desc: LiveData<String> = _desc

    private val _image = MutableLiveData<Int>()
    val image: LiveData<Int> = _image

    fun loadData(): List<GPUData>{
        return listOf(
            GPUData(R.string.gpu1, R.string.gpuprice1, R.string.gpudesc1, R.drawable.gpu1),
            GPUData(R.string.gpu2, R.string.gpuprice2, R.string.gpudesc2, R.drawable.gpu2),
            GPUData(R.string.gpu3, R.string.gpuprice3, R.string.gpudesc3, R.drawable.gpu3),
            GPUData(R.string.gpu4, R.string.gpuprice4, R.string.gpudesc4, R.drawable.gpu4),
            GPUData(R.string.gpu5, R.string.gpuprice5, R.string.gpudesc5, R.drawable.gpu5),
        )
    }
    fun setData(data: GPUData, context: Context){
        _name.value = context.getString(data.nameResourceId)
        _price.value = context.getString(data.priceResourceId)
        _desc.value = context.getString(data.descResourceId)
        _image.value = data.imgResourceId
    }
}