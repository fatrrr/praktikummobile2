package com.example.modul4.ui.cpu

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.modul4.R
import com.example.modul4.model.CPUData

class CPUViewModel : ViewModel() {

    private val _name = MutableLiveData<String>()
    val name: LiveData<String> = _name

    private val _price = MutableLiveData<String>()
    val price: LiveData<String> = _price

    private val _desc = MutableLiveData<String>()
    val desc: LiveData<String> = _desc

    private val _image = MutableLiveData<Int>()
    val image: LiveData<Int> = _image

    fun loadData(): List<CPUData>{
        return listOf(
            CPUData(R.string.cpu1, R.string.cpuprice1, R.string.cpudesc1, R.drawable.cpu1),
            CPUData(R.string.cpu2, R.string.cpuprice2, R.string.cpudesc2, R.drawable.cpu2),
            CPUData(R.string.cpu3, R.string.cpuprice3, R.string.cpudesc3, R.drawable.cpu3),
            CPUData(R.string.cpu4, R.string.cpuprice4, R.string.cpudesc4, R.drawable.cpu4),
            CPUData(R.string.cpu5, R.string.cpuprice5, R.string.cpudesc5, R.drawable.cpu5),
        )
    }
    fun setData(data: CPUData, context: Context){
        _name.value = context.getString(data.nameResourceId)
        _price.value = context.getString(data.priceResourceId)
        _desc.value = context.getString(data.descResourceId)
        _image.value = data.imgResourceId
    }
}