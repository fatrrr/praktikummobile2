package com.example.modul4.ui.ram

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.modul4.databinding.ActivityRamDetailBinding

class RAMDetailActivity : AppCompatActivity(){
    private var _binding: ActivityRamDetailBinding? = null
    private val binding get() = _binding!!

    companion object{
        const val EXTRA_IMAGE = "image"
        const val EXTRA_NAME = "name"
        const val EXTRA_PRICE = "price"
        const val EXTRA_DESCRIPTION = "description"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityRamDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val img = binding.imgRamDetail
        img.setImageResource(intent.getIntExtra(EXTRA_IMAGE, 0))

        val name = binding.nameRamDetail
        name.text = intent.getStringExtra(EXTRA_NAME)

        val price = binding.priceRamDetail
        price.text = intent.getStringExtra(EXTRA_PRICE)

        val desc = binding.descRamDetail
        desc.text = intent.getStringExtra(EXTRA_DESCRIPTION)
    }
}