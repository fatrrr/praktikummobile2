package com.example.konversimatauang

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.konversimatauang.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*
import com.example.konversimatauang.databinding.ActivityMainBinding.inflate

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = inflate(layoutInflater)
        setContentView(binding.root)

        binding.konversiButton.setOnClickListener { this.conversiCurr() }
    }
    private fun conversiCurr(){
        val stringInTextField = binding.inputCurrencyEditText.text.toString()
        val cost = stringInTextField.toDoubleOrNull()
        if (cost == null || cost == 0.0) {
            displayResult(0.0)
            return
        }
        val fr = when(binding.currencyOptions.checkedRadioButtonId){
            R.id.euro -> 15500
            R.id.usd -> 14500
            R.id.yen -> 100
            else -> 4000
        }
        val idr = cost * fr
        
        displayResult(idr)
    }
    private fun displayResult(idr: Double){
        val indonesianLocale = Locale("in", "ID")
        val formattedNum = NumberFormat.getCurrencyInstance(indonesianLocale).format(idr)
        binding.hasilKonversiText.text = getString(R.string.rupiah, formattedNum)
    }
}