package com.example.diceroller

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val gambar1: ImageView = findViewById(R.id.imageView1)
        gambar1.setImageResource(R.drawable.dice_0)
        val gambar2: ImageView = findViewById(R.id.imageView2)
        gambar2.setImageResource(R.drawable.dice_0)
        val rollButton: Button = findViewById(R.id.btn1)
        rollButton.setOnClickListener { acakDadu() }
    }
    private fun acakDadu() {
        val dice1 = Die(6)
        val dice2 = Die(6)
        val die1 = dice1.acak()
        val die2 = dice2.acak()
        val gambarDadu1: ImageView = findViewById(R.id.imageView1)
        val gambarDadu2: ImageView = findViewById(R.id.imageView2)
        val drawableResource1 = when (die1) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        gambarDadu1.setImageResource(drawableResource1)
        val drawableResource2 = when (die2) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        gambarDadu2.setImageResource(drawableResource2)
        if (die1 == die2){
            Toast.makeText(this, "Selamat anda dapat dadu double!",
                Toast.LENGTH_SHORT).show()
        } else Toast.makeText(this, "Anda belum beruntung!",
            Toast.LENGTH_SHORT).show()
    }
    class Die(private val nilai : Int){
        fun acak(): Int{
            return (1..nilai).random()
        }
    }
}